﻿// <copyright file="TestClass.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace NUnit.SpreadsheetTest
{
    using System.Collections;
    using System.Collections.Generic;
    using NUnit.Framework;
    using Spreadsheet_Adam_Clobes;
    using SpreadsheetEngine;

    /// <summary>
    /// Test class for testing component of project.
    /// </summary>
    [TestFixture]
    public class TestClass
    {
        // Test letter case
        [Test]
        public void TestCell1()
        {
            RealCell cell1 = new RealCell('A', 1);
            Assert.That(cell1.ColumnIndex, Is.EqualTo('A'), "TestCell1 machine broke");
        }

        // test integer case
        [Test]
        public void TestCell2()
        {
            RealCell cell1 = new RealCell(36, 1);
            Assert.That(cell1.ColumnIndex, Is.EqualTo(36), "TestCell2 machine broke");
        }

        // test normal
        [Test]
        public void TestSpreadsheet1()
        {
            Spreadsheet spreadsheet = new Spreadsheet(26, 50);
            Assert.That(spreadsheet.ColumnCount, Is.EqualTo(26), "TestSpreadsheet1 machine broke");
        }

        // test min
        [Test]
        public void TestSpreadsheet3()
        {
            Spreadsheet spreadsheet = new Spreadsheet(1, 1);
            Assert.That(spreadsheet.ColumnCount, Is.EqualTo(1), "TestSpreadsheet3 machine broke");
        }

        // test creation of ExpressionTree class
        [Test]
        public void TestETClass()
        {
            ExpressionTree expressTree = new ExpressionTree("1+1");
            Assert.That(expressTree, !Is.Null, "TestETClass machine broke");
        }

        // test set variable norm
        [Test]
        public void TestETSetVariable1()
        {
            ExpressionTree expressTree = new ExpressionTree("1+A");
            expressTree.SetVariable("A", 2.0);
            Assert.That(expressTree.Evaluate(), Is.EqualTo(3.0), "TestETSetVariable1 machine broke");
        }

        // test set variable negative
        [Test]
        public void TestETSetVariable2()
        {
            ExpressionTree expressTree = new ExpressionTree("1+A");
            expressTree.SetVariable("A", -2.0);
            Assert.That(expressTree.Evaluate(), Is.EqualTo(-1.0), "TestETSetVariable2 machine broke");
        }

        // test set variable extreme
        [Test]
        public void TestETSetVariable3()
        {
            ExpressionTree expressTree = new ExpressionTree("1+A");
            expressTree.SetVariable("A", 0.000001);
            Assert.That(expressTree.Evaluate(), Is.EqualTo(1.000001), "TestETSetVariable3 machine broke");
        }

        // test evaluation norm
        [Test]
        public void TestETEvaluate1()
        {
            ExpressionTree expressTree = new ExpressionTree("1+1");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(2), "TestETEvaluate1 machine broke");
        }

        // test evaluation neg
        [Test]
        public void TestETEvaluate2()
        {
            ExpressionTree expressTree = new ExpressionTree("1-1");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(0), "TestETEvaluate2 machine broke");
        }

        // test evaluation multiply
        [Test]
        public void TestETEvaluate3()
        {
            ExpressionTree expressTree = new ExpressionTree("2*2");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(4), "TestETEvaluate3 machine broke");
        }

        // test evaluation divide
        [Test]
        public void TestETEvaluate4()
        {
            ExpressionTree expressTree = new ExpressionTree("2/2");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(1), "TestETEvaluate4 machine broke");
        }

        // test evaluation norm
        [Test]
        public void TestETEvaluate5()
        {
            ExpressionTree expressTree = new ExpressionTree("1+1-1*1/1");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(1), "TestETEvaluate1 machine broke");
        }

        // test evaluation neg
        [Test]
        public void TestETEvaluate6()
        {
            ExpressionTree expressTree = new ExpressionTree("0.001+0.001-0.001*0.001/0.001");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(0.001), "TestETEvaluate2 machine broke");
        }

        // test evaluation multiply
        [Test]
        public void TestETEvaluate7()
        {
            ExpressionTree expressTree = new ExpressionTree("(1-51)/2");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(-25), "TestETEvaluate3 machine broke");
        }

        // test evaluation divide
        [Test]
        public void TestETEvaluate8()
        {
            ExpressionTree expressTree = new ExpressionTree("(((((1+1)))))");
            Assert.That(expressTree.Evaluate(), Is.EqualTo(2), "TestETEvaluate4 machine broke");
        }

        // test save method
        [Test]
        public void TestSave()
        {
            Spreadsheet spreadsheet = new Spreadsheet();
            XMLStream XMLStream = new XMLStream(spreadsheet);
            bool Savedright;
            if (Save(XMLStream) == true)
                Savedright = true;
            else
                Savedright = false;
            Assert.That(Savedright, Is.EqualTo(true), "Save machine broke");
        }

        // test load method
        [Test]
        public void TestSave()
        {
            Spreadsheet spreadsheet = new Spreadsheet();
            XMLStream XMLStream = new XMLStream(spreadsheet);
            bool Loadedright;
            if (Load(XMLStream) == true)
                Loadedright = true;
            else
                Loadedright = false;
            Assert.That(Loadedright, Is.EqualTo(true), "Save machine broke");
        }

    }
}
