﻿// <copyright file="OperatorNodeFactory.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Operator Node Factory.
    /// </summary>
    public static class OperatorNodeFactory
    {
        /// <summary>
        /// Returns a new operator node of operator given.
        /// </summary>
        /// <param name="op">op.</param>
        /// <returns>Operator node.</returns>
        public static OperatorNode CreateNode(string op)
        {
            switch (op)
            {
                case "+":
                    return new AdditionNode();
                case "-":
                    return new SubtractionNode();
                case "*":
                    return new MultiplicationNode();
                case "/":
                    return new DivisionNode();
                default:
                    throw new NotSupportedException("Operator unsupported.");
            }
        }
    }
}
