﻿namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Command class for background colors.
    /// </summary>
    public class BGColorCommand : Command
    {
        private Dictionary<Cell, uint> refCellDictionary;
        private uint newColor;


        /// <summary>
        /// Initializes a new instance of the <see cref="BGColorCommand"/> class.
        /// </summary>
        /// <param name="color">Color added.</param>
        /// <param name="list">List of highlighted cells.</param>
        public BGColorCommand(uint color, List<Cell> list)
        {
            this.refCellDictionary = new Dictionary<Cell, uint>();
            foreach (Cell cell in list)
            {
                // adds selected cells and their current colors to the dictionary
                this.refCellDictionary.Add(cell, cell.Color);
            }

            this.newColor = color;
        }

        /// <summary>
        /// For each cell that was highlighted, replaces color with their old color.
        /// </summary>
        public override void Undo()
        {
            foreach (KeyValuePair<Cell, uint> cell in this.refCellDictionary)
            {
                cell.Key.Color = cell.Value;
            }

        }

        /// <summary>
        /// For every cell highlighted, replaces color with new color.
        /// </summary>
        public override void Execute()
        {
            foreach (KeyValuePair<Cell, uint> cell in this.refCellDictionary)
            {
                cell.Key.Color = this.newColor;
            }
        }
    }
}
