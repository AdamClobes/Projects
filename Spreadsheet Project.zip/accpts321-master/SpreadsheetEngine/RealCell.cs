﻿// <copyright file="RealCell.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

/// <summary>
/// RealCell object class. Used to create non-abstract cells.
/// </summary>
namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using SpreadsheetEngine;

    /// <summary>
    /// Class RealCell.
    /// </summary>
    public class RealCell : Cell
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RealCell"/> class.
        /// Constructor for RealCell.
        /// </summary>
        /// <param name="col">Column index.</param>
        /// <param name="row">Row index.</param>
        public RealCell(int col, int row)
            : base(col, row)
        {
        }
    }
}
