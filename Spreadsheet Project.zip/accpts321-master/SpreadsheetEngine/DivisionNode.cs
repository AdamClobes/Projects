﻿// <copyright file="DivisionNode.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// DivisionNode Class.
    /// </summary>
    public class DivisionNode : OperatorNode
    {
        // precedence of addition.
        private int precedence = 3;

        /// <summary>
        /// Gets precedence.
        /// </summary>
        public int Precedence
        {
            get
            {
                return this.precedence;
            }
        }

        /// <summary>
        /// Evaluates division of children (L/R).
        /// </summary>
        /// <returns>Evaluated value.</returns>
        public override double Evaluate()
        {
            return this.Left.Evaluate() / this.Right.Evaluate();
        }
    }
}
