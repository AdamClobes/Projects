﻿// <copyright file="VariableNode.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// VariableNode Class.
    /// </summary>
    public class VariableNode : Node
    {
        // name and variable values in node
        private readonly string name;
        private Dictionary<string, double> variables;

        /// <summary>
        /// Initializes a new instance of the <see cref="VariableNode"/> class.
        /// </summary>
        /// <param name="name">name key.</param>
        /// <param name="variables">variable for node.</param>
        public VariableNode(string name, ref Dictionary<string, double> variables)
        {
            this.name = name;
            this.variables = variables;
        }

        /// <summary>
        /// Sets value to new value.
        /// </summary>
        /// <param name="name">name key.</param>
        /// <param name="variables">new value.</param>
        public void SetValue(string name, ref Dictionary<string, double> variables)
        {
            if (this.variables.ContainsKey(this.name))
            {
                this.variables = variables;
            }
        }

        /// <summary>
        /// Gets value in node to evaluate.
        /// </summary>
        /// <returns>value in node.</returns>
        public override double Evaluate()
        {
            var value = 0.0;
            if (this.variables.ContainsKey(this.name))
            {
                value = this.variables[this.name];
            }

            return value;
        }
    }
}
