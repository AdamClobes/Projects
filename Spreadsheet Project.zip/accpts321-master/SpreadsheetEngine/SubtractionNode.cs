﻿// <copyright file="SubtractionNode.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// SubtractionNode Class.
    /// </summary>
    public class SubtractionNode : OperatorNode
    {
        // precedence of addition.
        private int precedence = 4;

        /// <summary>
        /// Gets precedence.
        /// </summary>
        public int Precedence
        {
            get
            {
                return this.precedence;
            }
        }

        /// <summary>
        /// Evaluates children node.
        /// </summary>
        /// <returns>Evaluated value.</returns>
        public override double Evaluate()
        {
            return this.Left.Evaluate() - this.Right.Evaluate();
        }
    }
}
