﻿namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Command class for spreadsheet commands.
    /// </summary>
    public class CellTextCommand : Command
    {

        public Cell cellChanged;
        private string oldText;
        private string newText;

        public CellTextCommand(Cell cell, string incOldText, string incNewText)
        {
            this.cellChanged = cell;
            this.oldText = incOldText;
            this.newText = incNewText;
        }

        /// <summary>
        /// Getter for description.
        /// </summary>
        /// <returns>Description.</returns>
        public override void Undo()
        {
            this.cellChanged.Text = this.oldText;
        }

        /// <summary>
        /// Getter for command.
        /// </summary>
        public override void Execute()
        {
            this.cellChanged.Text = this.newText;
        }
    }
}