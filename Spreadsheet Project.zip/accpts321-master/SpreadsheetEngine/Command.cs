﻿namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Parent abstract class for commands.
    /// </summary>
    public abstract class Command
    {
        // text description of command given
        public string description;

        /// <summary>
        /// Undoes the last command and pushes it to the redo stack.
        /// </summary>
        /// <returns>Command.</returns>
        public abstract void Undo();

        /// <summary>
        /// Executes current command.
        /// </summary>
        /// <returns>Command.</returns>
        public abstract void Execute();
    }
}
