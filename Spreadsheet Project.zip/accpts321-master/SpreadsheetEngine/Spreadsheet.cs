﻿// <copyright file="Spreadsheet.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

/// <summary>
/// Engine for spreadsheet. Creates a virtual spreadsheet and to interacts with both
/// the gui and the virtual spreadsheet to bridge data between the two.
/// </summary>
namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml;

    /// <summary>
    /// Spreadsheet class.
    /// </summary>
    public class Spreadsheet
    {
        // Spreadsheet variables
        private Cell[,] cellID;
        private Dictionary<string, int> currentlocal = new Dictionary<string, int> { };
        private ExpressionTree expTree;

        // indexes for coordinates
        private int numCol;
        private int numRow;

        public Dictionary<string, List<string>> cellReferences;

        private Stack<Command> undoStack;
        private Stack<Command> redoStack;

        public void PushUndo(Command command)
        {
            this.undoStack.Push(command);
            this.StackCountChanged?.Invoke(this, new PropertyChangedEventArgs("Undo"));
        }

        public void Undo()
        {
            Command command = this.undoStack.Pop();
            command.Undo();
            this.redoStack.Push(command);
            this.StackCountChanged?.Invoke(this, new PropertyChangedEventArgs("Redo"));

        }

        public void Redo()
        {
            Command command = this.redoStack.Pop();
            command.Execute();
            this.undoStack.Push(command);
            this.StackCountChanged?.Invoke(this, new PropertyChangedEventArgs("Undo"));
        }

        public int GetStackSize(string stackname)
        {
            if (stackname == "Undo")
            {
                return this.undoStack.Count;
            }
            else
            {
                return this.redoStack.Count;

            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Spreadsheet"/> class.
        /// </summary>
        /// <param name="col">Column value.</param>
        /// <param name="row">Row value.</param>
        public Spreadsheet(int col, int row)
        {
            this.cellID = new Cell[col, row];
            this.numCol = col;
            this.numRow = row;
            this.cellReferences = new Dictionary<string, List<string>>();
            this.undoStack = new Stack<Command>();
            this.redoStack = new Stack<Command>();

            for (int i = 0; i < col; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    this.cellID[i, j] = new RealCell(i, j);
                    this.cellID[i, j].PropertyChanged += this.OnPropertyChanged;
                }
            }

            // number of alphabet
            for (int i = 0; i < 26; i++)
            {
                this.currentlocal.Add(((char)i).ToString(), i);
            }
        }

        /// <summary>
        /// Event handler for propert changed.
        /// </summary>
        public event PropertyChangedEventHandler CellPropertyChanged = (sender, e) => { };

        public event PropertyChangedEventHandler StackCountChanged = (sender, e) => { };

        /// <summary>
        /// converting text given to text in cell.
        /// </summary>
        /// <param name="text">Text in the cell.</param>
        /// <returns>Text in the outward cell.</returns>
        public string GetText(string text)
        {
            return this.GetCell(Convert.ToInt32(text[1].ToString()), this.currentlocal[text[1].ToString()]).Text;
        }

        /// <summary>
        /// Checks if given cell coordinates are in bounds and returns it.
        /// </summary>
        /// <param name="col">Column index.</param>
        /// <param name="row">Row index.</param>
        /// <returns>Cell in coordinates.</returns>
        public Cell GetCell(int col, int row)
        {
            // check if its out or in bounds
            if (col <= this.numCol && row <= this.numRow && col >= 0 && row >= 0)
            {
                return this.cellID[col, row];
            }
            else
            {
                // if its not, its null
                return null;
            }
        }

        /// <summary>
        /// Parses given input into the spreadsheet.
        /// </summary>
        /// <param name="cellName">Data put into spreadsheet.</param>
        /// <returns>Parsed cell.</returns>
        public Cell GetCell(string cellName)
        {
            // col == the letter converted from ASCII to int
            var col = Convert.ToInt32(cellName[0]) - 'A';
            var row = cellName.Substring(1);

            // converts it all back to int and returns it
            return this.GetCell(col, Convert.ToInt32(row) - 1);
        }

        /// <summary>
        /// Getter or rowCount.
        /// </summary>
        /// <returns>numRow.</returns>
        public int RowCount()
        {
            return this.numRow;
        }

        /// <summary>
        /// Getter for numCol.
        /// </summary>
        /// <returns>numCol.</returns>
        public int ColumnCount()
        {
            return this.numCol;
        }

        /// <summary>
        /// Creates a non-abstract Cell object and uses it to compare the given
        /// value and text to the abstract cell and calls GetCell to parse it.
        /// </summary>
        /// <param name="sender">object sent.</param>
        /// <param name="e">thing interacted with.</param>
        private void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            Cell realCell = sender as Cell;

            if (e.PropertyName == "Text")
            {
                // if it starts with =, set the value inside that cell to the cell given
                if (realCell.Text.StartsWith("="))
                {

                    // create string to be substringed
                    string exp = realCell.Text.Substring(1);
                    List<string> references = new List<string>();

                    // create expression tree from text (cuts off the '=' using substring)
                    this.expTree = new ExpressionTree(exp);

                    // runs through the expression, grabs any variables in it and sets them to the
                    // values of corresponding cell names (given that they are filled)
                    foreach (string variable in this.expTree.GetVariables())
                    {
                        Cell refCell = this.GetCell(variable);
                        refCell.PropertyChanged += realCell.OnPropertyChanged;
                        references.Add(variable);
                        string value = refCell.Value;
                        if (double.TryParse(value, out double num))
                        {
                            this.expTree.SetVariable(variable, num);
                        }
                        else
                        {
                            this.expTree.SetVariable(variable, 0);
                        }
                    }

                    if (this.cellReferences.ContainsKey(realCell.GetLocation()))
                    {
                        foreach (string refs in this.cellReferences[realCell.GetLocation()])
                        {
                            if (!references.Contains(refs))
                            {
                                Cell cell1 = this.GetCell(refs);
                                cell1.PropertyChanged -= realCell.OnPropertyChanged;
                            }
                        }
                    }

                    this.cellReferences[realCell.GetLocation()] = references;
                    realCell.Value = this.expTree.Evaluate().ToString();
                    this.CellPropertyChanged?.Invoke(sender, new PropertyChangedEventArgs("Value"));
                }

                // else just make the value and text the same
                else
                {
                    realCell.Value = realCell.Text;
                    this.CellPropertyChanged?.Invoke(sender, new PropertyChangedEventArgs("Value"));
                }
            }
            else if (e.PropertyName == "Background Color")
            {
                this.CellPropertyChanged?.Invoke(sender, new PropertyChangedEventArgs("Background Color"));
            }
        }

        /// <summary>
        /// Saves spreadsheet to file.
        /// </summary>
        /// <param name="stream">Out stream.</param>
        public void Save(Stream stream)
        {
            XmlWriter writer = XmlWriter.Create(stream);
            writer.WriteStartDocument();
            writer.WriteStartElement("Spreadsheet");
            string cell = string.Empty;

            for (int col = 0; col < 26; col++)
            {
                for (int row = 0; row < 50; row++)
                {
                    Cell temp = this.GetCell(col, row);
                    if (temp.Text != string.Empty || temp.Value != string.Empty || temp.Color != 0xFFFFFFFF)
                    {
                        cell = ((char)(col + 65)).ToString() + (row + 1).ToString();

                        // element for cell
                        writer.WriteStartElement("Cell");

                        // element for cell text
                        this.WriteSave(writer, temp, "cell_text", "text");

                        // element for cell column
                        this.WriteSave(writer, temp, "cell_col", "col");

                        // element for cell row
                        this.WriteSave(writer, temp, "cell_row", "row");

                        // element for cell value
                        this.WriteSave(writer, temp, "cell_value", "value");

                        // element for color
                        this.WriteSave(writer, temp, "cell_color", "color");

                        // once more, with feeling
                        writer.WriteEndElement();
                    }
                }
            }

            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
        }

        /// <summary>
        /// Helper function to set up writers.
        /// </summary>
        /// <param name="writer">Xmlwriter writing to file.</param>
        /// <param name="temp">Cell being added.</param>
        /// <param name="name">Name of cell being added.</param>
        /// <param name="element">Element of the cell being added.</param>
        private void WriteSave(XmlWriter writer, Cell temp, string name, string element)
        {
            writer.WriteStartElement(name);
            switch (element)
            {
                case "text":
                    writer.WriteString(temp.Text);
                    break;
                case "col":
                    writer.WriteString(temp.ColumnIndex().ToString());
                    break;
                case "row":
                    writer.WriteString(temp.RowIndex().ToString());
                    break;
                case "value":
                    writer.WriteString(temp.Value);
                    break;
                case "color":
                    writer.WriteString(temp.Color.ToString());
                    break;
                default:
                    return;
            }
            writer.WriteEndElement();
        }



        /// <summary>
        /// Loads file into spreadsheet.
        /// </summary>
        /// <param name="stream">In stream.</param>
        public void Load(Stream stream)
        {
            XmlReader reader = XmlReader.Create(stream);
            reader.ReadStartElement("Spreadsheet");
            string text = string.Empty;
            string value = string.Empty;
            Cell cell;
            int col = 0;
            int row = 0;
            uint color = 0;

            while (reader.Name == "Cell")
            {
                reader.ReadStartElement("Cell");

                reader.ReadStartElement("cell_text");
                text = reader.ReadContentAsString();
                reader.ReadEndElement();

                reader.ReadStartElement("cell_col");
                col = reader.ReadContentAsInt();
                reader.ReadEndElement();

                reader.ReadStartElement("cell_row");
                row = reader.ReadContentAsInt();
                reader.ReadEndElement();

                reader.ReadStartElement("cell_value");
                value = reader.ReadContentAsString();
                reader.ReadEndElement();

                reader.ReadStartElement("cell_color");
                color = Convert.ToUInt32(reader.ReadContentAsString());
                reader.ReadEndElement();

                cell = this.GetCell(col, row);

                this.LoadCell(cell, col, row, color, value, text);
                reader.ReadEndElement();
            }

            reader.ReadEndElement();
            reader.Close();
        }


        /// <summary>
        /// Loads cell with given input.
        /// </summary>
        /// <param name="cell">Cell.</param>
        /// <param name="col">Column.</param>
        /// <param name="row">Row.</param>
        /// <param name="color">Color.</param>
        /// <param name="value">Value.</param>
        /// <param name="text">Text.</param>
        private void LoadCell(Cell cell, int col, int row, uint color, string value, string text)
        {
            cell.ColumnIndex(col);
            cell.RowIndex(row);
            cell.Color = color;
            cell.Value = value;
            cell.Text = text;
        }

    }
}
