﻿// <copyright file="OperatorNode.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// OperatorNode class.
    /// </summary>
    public abstract class OperatorNode : Node
    {
        /// <summary>
        /// Gets or sets left node.
        /// </summary>
        public Node Left { get; set; }

        /// <summary>
        /// Gets or sets right node.
        /// </summary>
        public Node Right { get; set; }
    }
}
