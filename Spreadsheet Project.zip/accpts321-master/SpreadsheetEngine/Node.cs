﻿// <copyright file="Node.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Node class.
    /// </summary>
    public abstract class Node
    {
        /// <summary>
        /// Abstracted evaluate to be inhereted.
        /// </summary>
        /// <returns>Value evaluated.</returns>
        public abstract double Evaluate();
    }
}
