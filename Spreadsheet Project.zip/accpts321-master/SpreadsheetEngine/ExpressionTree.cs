﻿// <copyright file="ExpressionTree.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;

    /// <summary>
    /// Expression Tree class.
    /// </summary>
    public class ExpressionTree
    {
        // strings and expression holders
        public string[] valueString;
        private string thisExpression;

        // elements of tree
        public Dictionary<string, double> variables;
        private Node root;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTree"/> class.
        /// </summary>
        /// <param name="expression">String expression to be solved.</param>
        public ExpressionTree(string expression)
        {
            this.variables = new Dictionary<string, double>();
            string[] postFix = this.PostFix(expression);
            this.root = this.ConstructTree(postFix);
        }

        /// <summary>
        /// Gets or sets Expression.
        /// </summary>
        public string Expression
        {
            get
            {
                return this.thisExpression;
            }

            set
            {
                this.thisExpression = value;
                string[] postFix = this.PostFix(value);
                this.variables = new Dictionary<string, double>();
                this.root = this.ConstructTree(postFix);
            }
        }

        /// <summary>
        /// Sets new value of given variable.
        /// </summary>
        /// <param name="variableName">Variable name we're looking for in the tree.</param>
        /// <param name="variableValue">New value the variable will be set to.</param>
        public void SetVariable(string variableName, double variableValue)
        {
            if (!this.variables.ContainsKey(variableName))
            {
                this.variables.Add(variableName, variableValue);
            }
            else
            {
                this.variables[variableName] = variableValue;
            }
        }

        /// <summary>
        /// Mathematically solves the given expression.
        /// </summary>
        /// <returns>Result of expression.</returns>
        public double Evaluate()
        {
            return this.root.Evaluate();
        }

        /// <summary>
        /// Converts string array given to postfix.
        /// </summary>
        /// <param name="s">string[] given.</param>
        /// <returns>postfix version of string[].</returns>
        public string[] PostFix(string s)
        {
            List<string> list = new List<string>();
            Stack stack = new Stack();

            // parse using regex
            string oRegex = @"([\(\+\-\*\/\)])";
            s = s.Replace(" ", string.Empty);
            string[] sArray = Regex.Split(s, oRegex);

            for (int i = 0; i < sArray.Length; i++)
            {
                if (string.IsNullOrEmpty(sArray[i]))
                {
                    continue;
                }
                else if (this.IsOp(sArray[i]) || this.IsPara(sArray[i]))
                {
                    // 2. if stack is empty or contains ( on top, push incoming op
                    if (stack.Count == 0 || stack.Peek().ToString() == "(" || sArray[i] == ")")
                    {
                        // 3. if incoming symbol is ( push it on stack
                        if (sArray[i] == "(")
                        {
                            stack.Push(sArray[i]);
                        }

                        // 4. if inc is ) pop stack and print op until you see (
                        else if (sArray[i] == ")")
                        {
                            // 4.2 pop the stack until you see a left parathesis
                            while (stack.Peek().ToString() != "(")
                            {
                                list.Add(stack.Pop().ToString());
                            }

                            // discard left parathesis
                            stack.Pop();
                        }

                        // 2.2 add op to stack
                        else
                        {
                            stack.Push(sArray[i]);
                        }
                    }

                    // stack != 0 or isnt a "("
                    else
                    {
                        // breaker for loop
                        bool breako = false;

                        // 3. if incoming symbol is ( push it on stack
                        if (sArray[i] == "(")
                        {
                            stack.Push(sArray[i]);
                            breako = true;
                        }

                        // while will allow this block to repeat if needed
                        while (!breako)
                        {
                            breako = false;

                            // 5-7 if stack has an op in it
                            if (stack.Count > 0)
                            {

                                // 5. if inc has higher precedence than top of stack, push it
                                if (this.GetPrecedence(sArray[i]) < this.GetPrecedence(stack.Peek().ToString()))
                                {
                                    stack.Push(sArray[i]);

                                    // get out of here
                                    breako = true;
                                }

                                // 6. if its equal precedence, use association
                                else if (this.GetPrecedence(sArray[i]) == this.GetPrecedence(stack.Peek().ToString()))
                                {
                                    list.Add(stack.Pop().ToString());
                                    stack.Push(sArray[i]);

                                    // get out of here
                                    breako = true;
                                }

                                // 7. if its less than, pop stack and print top op; test new ops against stack top
                                else
                                {
                                    // if inc is less precedence,
                                    while (this.GetPrecedence(sArray[i]) > this.GetPrecedence(stack.Peek().ToString()))
                                    {
                                        list.Add(stack.Pop().ToString());
                                    }

                                    // repeat to test again
                                    breako = false;
                                }
                            }

                            // stack has no op in it
                            else
                            {
                                stack.Push(sArray[i]);

                                // get out of here
                                breako = true;
                            }
                        }
                    }
                }

                // 1. add operand as it comes
                else
                {
                    list.Add(sArray[i]);
                }
            }

            // make sure the rest on the stack is added
            while (stack.Count > 0)
            {
                list.Add(stack.Pop().ToString());
            }

            // turn list into string array
            string[] newString = new string[list.Count()];
            for (int i = 0; i < list.Count(); i++)
            {
                newString[i] = list[i];
            }

            return newString;
        }

        /// <summary>
        /// Uses postfix expression to create expression tree.
        /// </summary>
        /// <param name="postFix">postfix expression.</param>
        /// <returns>built expression tree.</returns>
        public Node ConstructTree(string[] postFix)
        {

            Stack<Node> stack = new Stack<Node>();
            string ops = "+-*/";
            //string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            foreach (string current in postFix)
            {

                // if this is an operator
                if (stack.Count > 0 && ops.Contains(current))
                {
                    OperatorNode opNode = OperatorNodeFactory.CreateNode(current);
                    opNode.Right = stack.Pop();
                    opNode.Left = stack.Pop();
                    stack.Push(opNode);
                }
                else
                {

                    // if it's a value
                    if (double.TryParse(current, out double value))
                    {
                        stack.Push(new ConstantNode(value));
                    }

                    // otherwise it's a variable
                    else
                    {
                        stack.Push(new VariableNode(current, ref this.variables));
                        this.variables.Add(current, 0);
                    }
                }
            }

            Node head = null;
            if (stack.Count != 0)
            {
                head = stack.Pop();
            }

            return head;
        }

        /// <summary>
        /// checks if given char is an operator.
        /// </summary>
        /// <param name="c">given string.</param>
        /// <returns>bool of if its an op.</returns>
        public bool IsOp(string s)
        {
            if (s == "+" || s == "-" || s == "*" || s == "/")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// checks if given char is an parathetical.
        /// </summary>
        /// <param name="c">given string.</param>
        /// <returns>bool of if its a para.</returns>
        public bool IsPara(string s)
        {
            if (s == "(" || s == ")")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Returns the precedence of given op.
        /// </summary>
        /// <param name="op">op.</param>
        /// <returns>precedence.</returns>
        public int GetPrecedence(string op)
        {
            switch (op)
            {
                case "+":
                    return 4;
                case "-":
                    return 4;
                case "*":
                    return 3;
                case "/":
                    return 3;
                default:
                    throw new NotSupportedException("Operator unsupported.");
            }
        }

        /// <summary>
        /// Returns the dictionary of variable names and their values.
        /// </summary>
        /// <returns>Dictionary of variables.</returns>
        public List<string> GetVariables()
        {
            return this.variables.Keys.ToList();
        }
    }
}
