﻿// <copyright file="Cell.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

/// <summary>
/// Cell abstract class. Holds the whereabouts and data stored in each cell.
/// </summary>
namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Cell class.
    /// </summary>
    public abstract class Cell : INotifyPropertyChanged
    {
        // cell object variables
        private int columnIndex;
        private int rowIndex;
        private protected string cellText;
        private protected string value;
        private protected uint BGColor;

        /// <summary>
        /// Initializes a new instance of the <see cref="Cell"/> class.
        /// </summary>
        /// <param name="col">column index.</param>
        /// <param name="row">row index.</param>
        public Cell(int col, int row)
        {
            this.columnIndex = col;
            this.rowIndex = row;
            this.cellText = string.Empty;
            this.value = string.Empty;
            this.BGColor = 0xFFFFFFF;
        }

        /// <summary>
        /// Event handler for Property changed.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged = (sender, e) => { };

        /// <summary>
        /// Gets or sets text value inside cell.
        /// </summary>
        public string Text
        {
            // return whats inside
            get
            {
                return this.cellText;
            }

            set
            {
                // if the given is the same as whats in it, dont do nothin'
                if (this.cellText == value)
                {
                    return;
                }

                // set new value and respond that a change was made
                else
                {
                    this.cellText = value;
                    this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Text")); // everyone that is interest in this change should be notified
                }
            }
        }

        /// <summary>
        /// Gets or sets value.
        /// </summary>
        public string Value
        {
            // get value
            get
            {
                return this.value;
            }

            set
            {
                // if the value its being given is the same, dont do anything
                if (this.value == value)
                {
                    return;
                }
                else
                {
                    // if it isnt, set it to the new value
                    this.value = value;

                    // tell the spreadsheet that there was an interaction
                    // this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Value"));
                }
            }
        }

        /// <summary>
        /// Gets or sets color.
        /// </summary>
        public uint Color
        {
            // get value
            get
            {
                return this.BGColor;
            }

            set
            {
                // if the value its being given is the same, dont do anything
                if (this.BGColor == value)
                {
                    return;
                }
                else
                {
                    // if it isnt, set it to the new value
                    this.BGColor = value;

                    // tell the spreadsheet that there was an interaction
                    this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Background Color"));
                }
            }
        }

        /// <summary>
        /// Getter fpr column index.
        /// </summary>
        /// <returns>Column index.</returns>
        public int ColumnIndex()
        {
            return this.columnIndex;
        }

        /// <summary>
        /// Getter for row index.
        /// </summary>
        /// <returns>Row index.</returns>
        public int RowIndex()
        {
            return this.rowIndex;
        }

        /// <summary>
        /// Setter for column index.
        /// </summary>
        /// <param name="col">Index to give col.</param>
        public void ColumnIndex(int col)
        {
            this.columnIndex = col;
        }

        /// <summary>
        /// Setter for row index.
        /// </summary>
        /// <param name="row">Index to give row.</param>
        public void RowIndex(int row)
        {
            this.rowIndex = row;
        }

        /// <summary>
        /// Getter for text.
        /// </summary>
        /// <returns>Text in cell.</returns>
        public string GetText()
        {
            return this.cellText;
        }

        /// <summary>
        /// Returns the location of the current cell in the form 'A1.'
        /// </summary>
        /// <returns>Cell location.</returns>
        public string GetLocation()
        {
            return ((char)(this.columnIndex + 65)) + string.Empty + (this.rowIndex + 1);
        }

        /// <summary>
        /// Fires when the property of the cell is changed. Used for subscription.
        /// </summary>
        /// <param name="sender">What changed.</param>
        /// <param name="e">How it changed.</param>
        public void OnPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            this.PropertyChanged?.Invoke(this, e);
        }
    }
}
