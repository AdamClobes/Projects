﻿namespace Console
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using SpreadsheetEngine;

    /// <summary>
    /// ConsoleMain class. Used as a driver for the console menu of project.
    /// </summary>
    class ConsoleMain
    { 

        /// <summary>
        /// Main for console app.
        /// </summary>
        static void Main()
        {
            ConsoleMain menu = new ConsoleMain();
            int input = 0;
            ExpressionTree expTree = new ExpressionTree("");
            while (input != 4)
            {
                menu.MenuPrompt(expTree);

                // menu options driver
                input = Convert.ToInt32(Console.ReadLine());
                switch (input)
                {

                    // enter new expression
                    case 1:
                        Console.Write("Enter new expression: ");
                        expTree.Expression = Console.ReadLine();
                        break;

                    // set variable value
                    case 2:
                        string name;
                        double value;
                        Console.Write("Set variable name: ");
                        name = Console.ReadLine(); // read in name
                        Console.Write("Set variable value: ");
                        value = Convert.ToDouble(Console.ReadLine()); // read in value
                        expTree.SetVariable(name, value);
                        break;

                    // evaluate tree
                    case 3:
                        Console.WriteLine(expTree.Evaluate());
                        break;

                    // quit
                    case 4:
                        break;
                }
            }

            // exit
            Environment.Exit(0);
        }

        /// <summary>
        /// Displays the menu options and current Expression Tree.
        /// </summary>
        /// <param name="currentExp">The current expression.</param>
        private void MenuPrompt(ExpressionTree currentExp)
        {
            Console.Write("Menu (Current expression: " + currentExp.Expression +
                ")\r\n  1 = Enter a new expression\r\n  2 = Set a variable value\r\n" +
                "  3 = Evaluate tree\r\n  4 = Quit\r\n>");
        }
    }
}
