﻿// <copyright file="Form1.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

/// <summary>
/// Main and GUI for project. Interacts between spreadsheet and user GUI.
/// </summary>
namespace Spreadsheet_Adam_Clobes
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using SpreadsheetEngine;

    /// <summary>
    /// Class Form1.
    /// </summary>
    public partial class Form1 : Form
    {
        private Spreadsheet spreadsheet;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// Initializer for form component.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();
            this.spreadsheet = new SpreadsheetEngine.Spreadsheet(26, 50);
            this.spreadsheet.CellPropertyChanged += this.GUICellPropertyChanged;
            this.spreadsheet.StackCountChanged += this.OnStackChanged;
        }

        /// <summary>
        /// Fires all commands when form loads.
        /// </summary>
        /// <param name="sender">Form sender.</param>
        /// <param name="e">Object being interacted with.</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            // loop and create columns A-Z
            for (int i = 65; i < 91; i++)
            {
                var letter = Convert.ToChar(i);
                this.mainDataGrid.Columns.Add(Convert.ToString(letter), Convert.ToString(letter));
            }

            // loop and create rows 1-50
            for (int i = 1; i <= 50; i++)
            {
                DataGridViewRow newRow = new DataGridViewRow();
                DataGridViewRowHeaderCell rowHead = new DataGridViewRowHeaderCell();
                rowHead.Value = Convert.ToString(i);
                newRow.HeaderCell = rowHead;
                this.mainDataGrid.Rows.Add(newRow);
            }
        }

        /// <summary>
        /// Fires when a cell property changes.
        /// </summary>
        /// <param name="sender">object changing.</param>
        /// <param name="e">Thing interacted with.</param>
        private void GUICellPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            SpreadsheetEngine.Cell cell1 = (SpreadsheetEngine.Cell)sender;
            if (cell1 != null && e.PropertyName == "Value")
            {
                this.mainDataGrid.Rows[cell1.RowIndex()].Cells[cell1.ColumnIndex()].Value = cell1.Value;
            }
            else if (cell1 != null && e.PropertyName == "Background Color")
            {
                this.mainDataGrid.Rows[cell1.RowIndex()].Cells[cell1.ColumnIndex()].Style.BackColor = Color.FromArgb((int)cell1.Color);
            }
        }

        /// <summary>
        /// Shows the text value originally put in the cell when the cell is clicked.
        /// </summary>
        /// <param name="sender">Event sent.</param>
        /// <param name="e">Where event occured.</param>
        private void mainDataGrid_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            this.mainDataGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = this.spreadsheet.GetCell(e.ColumnIndex, e.RowIndex).Text;
        }

        /// <summary>
        /// Shows the value of the cell after the cell is clicked away from.
        /// </summary>
        /// <param name="sender">Event.</param>
        /// <param name="e">Event location.</param>
        private void mainDataGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (this.mainDataGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                Cell cell = this.spreadsheet.GetCell(e.ColumnIndex, e.RowIndex);
                string previousText = cell.Text;
                string newText = this.mainDataGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                CellTextCommand command = new CellTextCommand(cell, previousText, newText);
                command.Execute();
                this.spreadsheet.PushUndo(command);
            }
        }

        /// <summary>
        /// Changes color of cells that user selects.
        /// </summary>
        /// <param name="sender">Event.</param>
        /// <param name="e">Location.</param>
        private void changeColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.colorDialog.ShowDialog();
            uint newColor = (uint)this.colorDialog.Color.ToArgb();
            List<Cell> list = new List<Cell>();
            foreach (DataGridViewTextBoxCell cell in this.mainDataGrid.SelectedCells)
            {
                list.Add(this.spreadsheet.GetCell(cell.ColumnIndex, cell.RowIndex));
            }
            BGColorCommand command = new BGColorCommand(newColor, list);
            command.Execute();
            this.spreadsheet.PushUndo(command);
        }

        /// <summary>
        /// Updates the enable value of the Undo and Redo buttons depending on if there are
        /// commands in the stacks.
        /// </summary>
        /// <param name="sender">Event.</param>
        /// <param name="e">Location.</param>
        private void OnStackChanged(object sender, PropertyChangedEventArgs e)
        {
            bool undoBool = this.spreadsheet.GetStackSize("Undo") > 0;
            bool redoBool = this.spreadsheet.GetStackSize("Redo") > 0;
            this.undoToolStripMenuItem.Enabled = undoBool;
            this.redoToolStripMenuItem.Enabled = redoBool;
        }

        /// <summary>
        /// Undo previous command.
        /// </summary>
        /// <param name="sender">Event.</param>
        /// <param name="e">Location.</param>
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.spreadsheet.Undo();
        }

        /// <summary>
        /// Redo last undone command.
        /// </summary>
        /// <param name="sender">Event.</param>
        /// <param name="e">Locatio.</param>
        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.spreadsheet.Redo();
        }

        /// <summary>
        /// Saves the current spreadsheet to a file.
        /// </summary>
        /// <param name="sender">Event.</param>
        /// <param name="e">Location.</param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "xml|*.xml";
            save.ShowDialog();

            if (save.FileName != string.Empty)
            {
                System.IO.Stream file = save.OpenFile();
                this.spreadsheet.Save(file);
            }
        }

        /// <summary>
        /// Loads a spreadsheet and populates it into the spreadsheet GUI.
        /// </summary>
        /// <param name="sender">Event.</param>
        /// <param name="e">Location.</param>
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "xml|*.xml";
            open.ShowDialog();

            if (open.FileName.Contains("xml"))
            {
                this.Clear();
                System.IO.Stream readStream = open.OpenFile();
                this.spreadsheet.Load(readStream);
                readStream.Close();
            }
        }

        private void Clear()
        {
            // default colors for both the data grid and the cell
            uint defaultbgcolor = 0xFFFFFFFF;
            Color defaultColor = ToColor(defaultbgcolor);
            Cell newCell;

            // traverses through the datagrid and sheet to remove all contents
            for (int col = 0; col < 26; col++)
            {
                for (int row = 0; row < 50; row++)
                {
                    // reinitialize each of the values to default
                    this.mainDataGrid[col, row].Value = string.Empty;
                    this.mainDataGrid[col, row].Style.BackColor = defaultColor;
                    newCell = this.spreadsheet.GetCell(col, row);
                    newCell.Color = defaultbgcolor;
                    newCell.Text = string.Empty;
                    newCell.Value = string.Empty;
                }
            }
        }

        /// <summary>
        /// Converts uint value to a color and returns it.
        /// </summary>
        /// <param name="value">uint.</param>
        /// <returns>Color.</returns>
        private static Color ToColor(uint value)
        {
            return Color.FromArgb(
                       (byte)((value >> 24) & 0xFF),
                       (byte)((value >> 16) & 0xFF),
                       (byte)((value >> 8) & 0xFF),
                       (byte)(value & 0xFF));
        }

    }
}