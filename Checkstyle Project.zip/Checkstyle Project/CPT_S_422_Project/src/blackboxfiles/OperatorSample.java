
public class Sample {

	//7 operands total
	
    int x = 1 + 2 + 3 - 4 / 3 * 2;
    
}
