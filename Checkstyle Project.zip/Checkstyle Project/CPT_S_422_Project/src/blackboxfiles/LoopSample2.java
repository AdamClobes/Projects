
public class Sample {

	int x = 0;
	
	void main()
	{
		for(int i = 0; i < 10; i++)
		{

		}
		
		while(x < 2)
		{
			x++;
		}
		x = 0;
	}
    
}
