
package sample_code;


public class Sample {

	/**1 comments, 1 comment lines (including this one)**/
    
}
