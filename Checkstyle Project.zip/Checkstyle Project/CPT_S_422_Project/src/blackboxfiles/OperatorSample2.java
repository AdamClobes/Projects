
public class Sample {

	//12 operators total
	
    int x = 1 + 2 + 3;
    int y = 3;
    int z = x + y;
    
    public void inc()
    {
    	if(x == 3 && y == 3 || z == 9)
    	{
    		
    	}
    }
    
  //int a = 1 + 2;
}
