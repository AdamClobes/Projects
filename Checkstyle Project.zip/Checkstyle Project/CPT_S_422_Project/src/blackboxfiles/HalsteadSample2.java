
public class Sample {

	//length = 10
	//vocab = 4
	//volume = 20
	//difficulty = 3
	//effort = 60

	void main()
	{
		int x = 1 + 2 + 1 + 1 + 1 + 1;		
	}
	
    
}
