
public class Sample {

	void main()
	{
		//7 comments, 16 comment lines (including this one)
		
		/**
		 * 
		 */
		
		//
		
		/**
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 */
		
		//
		//
		//
	}

    
}
