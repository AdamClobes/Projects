
public class Sample {

	//3 comments, 7 comment lines (including this one)
	
	/**
	 * test
	 */
	
	/**
		test
	 */
    
}
